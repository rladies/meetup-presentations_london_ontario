library(HistData)
library(tidyverse)

data("Nightingale")

df <- Nightingale %>%
      # Get rid of rate to make life easier
      select(-ends_with('rate')) %>%
      # Pivot dataset from wide to long (1 row per metric per time pt)
      pivot_longer(cols = Disease:Other,
                   names_to = "Cause",
                   values_to = "Frequency") %>%
      # Calculate rate and convert data types
      mutate(Date = as.Date(Date),
             Incidence = round(10000 * Frequency / Army, 2))
