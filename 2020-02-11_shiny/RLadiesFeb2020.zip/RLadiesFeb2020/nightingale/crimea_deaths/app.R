library(shiny)
library(shinyWidgets)

library(tidyverse)
library(wesanderson)

library(plotly)
library(DT)

source("helper.R")

# install.packages(c("shiny", "tidyverse", "DT", "plotly", "shinyWidgets", "wesanderson", "HistData"))

# Define UI ----
ui <- fluidPage(

    # Application title 
    titlePanel("Causes of Death During Crimean War (1854-1856)"),

    # Sidebar  ----
    sidebarLayout(
        
        sidebarPanel(

            # shinyWidgets dropdown selection
            # https://github.com/dreamRs/shinyWidgets#select-picker
            pickerInput("cause",
                        h4("Select cause(s) of death:"),
                        choices = unique(df$Cause),
                        selected = unique(df$Cause),
                        multiple = TRUE,
                        options = list(`actions-box` = TRUE)
                        ),
            
            # Date Range Input 
            # https://github.com/rstudio/shiny-examples/blob/master/081-widgets-gallery/ui.R
            dateRangeInput("range",
                           h4("Select date range:"),
                           start = min(df$Date),
                           end = max(df$Date),
                           startview = "year")
            ),

        # Output panel ----
        mainPanel(
            
          # Standard plot
          # plotOutput("causePlot"),
            
          # Fancy plot
          plotlyOutput("causePlotly"),
          
          # Standard plot
          # tableOutput("causeTable"),
          
          # Fancy plot
          DTOutput("causeDataTable")
           
        )
      )
    )


# Define server logic ----
server <- function(input, output) {
    
    # When objects are updated frequently by filters, it is useful to store them 
    # in reactive objects. Essentially, it prevents everything from needing to 
    # be re-run and just updates what is necessary. This is particularly useful 
    # for large data sets. 
    
    dfFilter <- reactive({
        
        df %>%
            filter(Cause %in% input$cause,
                   Date >= input$range[1],
                   Date <= input$range[2])
        
    })
    
    # Standard ggPlot 
    output$causePlot <- renderPlot({
        
        dfFilter() %>%
            ggplot(aes(x = Date, y = Incidence, fill = Cause, group = Cause)) +
            geom_area(position = 'stack', alpha = 0.5) +
            labs(y = 'Monthly Incidence per 10K Soldiers') +
            scale_x_date(date_labels = "%b %Y", date_breaks = "3 months") +
            scale_fill_manual(values=wes_palette(n=3, name="Darjeeling1")) +
            theme_bw() 
        
    })
    
    # Fancy ggPlot
    output$causePlotly <- renderPlotly({
        
        # Define text we want displayed within tooltip
        p_text <- with(dfFilter(),
                       paste0('Date: ', Date, '<br>',
                              'Cause: ', Cause, '<br>',
                              'Army Strength: ', Army, '<br>',
                              'Frequency: ', Frequency, '<br>',
                              'Incidence per 10K: ', Incidence))
        
        # Store our ggplot object
        p <- dfFilter() %>%
            ggplot(aes(x = Date, y = Incidence, fill = Cause, group = Cause, 
                       text = p_text)) +
            geom_area(position = 'stack', alpha = 0.5) +
            labs(y = 'Monthly Incidence per 10K Soldiers') +
            scale_x_date(date_labels = "%b %Y", date_breaks = "3 months") +
            scale_fill_manual(values = wes_palette(n = 3, name = "Darjeeling1")) +
            theme_bw() +
            # Remove legend because details displayed on mouseover
            theme(legend.position = 'none') 
        
        # Convert ggplot to plotly
        ggplotly(p, tooltip = c("text"))
        
        
    })
    
    # Standard table
    output$causeTable <- renderTable({
        
        dfFilter() %>%
            select(Year, Month, Cause, Army, Frequency, Incidence)
        
    })
    
    # Fancy table
    output$causeDataTable <- renderDT({
        
        dfFilter() %>%
            select(Year, Month, Cause, Army, Frequency, Incidence)
        
    })
    
}

# Run the application ----
shinyApp(ui = ui, server = server)
